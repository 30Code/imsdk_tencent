package com.tencent.qcloud.presentation.viewfeatures;

/**
 * 群管理接口
 */
public interface GroupManageView {


}
